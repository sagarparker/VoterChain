const {Block,Blockchain}    =   require('./blockchain');
const moment                =   require('moment');
const io                    =   require('socket.io-client');
const socket                =   io.connect('http://localhost:5000', {reconnect: true});

//Creating new instance of the blockchain
var VoterChain = new Blockchain();

// Add a connect listener
socket.on('connect', function () {
    console.log('Connected to the VoterChain network');
});

// When there is a new block that should be mined in the network
socket.on('MineBlock',function(data){
    const currentChain = data.VoterChain.chain;

    //Seting the local chain instance to the latest chain in the network
    VoterChain.chain = currentChain;


    setTimeout(() => {
        //Mine Block
        const block = VoterChain.computeBlock(new 
            Block(moment().format('MMMM Do YYYY, h:mm:ss a'),{voterID:data.voterID,vote:data.party}));

        //Emit the mined block back to the API server
        socket.emit("BlockMined",block); 
    }, 5000);

  


 
});


socket.on("validateBlock",function(block,Voterchain){
    const lastBlock = Voterchain.chain[Voterchain.chain.length-1];
    if(block.previousHash == lastBlock.hash){
        socket.emit("BlockIsValid",true,block);
    }
})






